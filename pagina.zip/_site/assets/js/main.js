function toggleNav(){
  const nav = document.querySelector('.nav');
  if (!nav) return;
  nav.classList.toggle('open');
}
