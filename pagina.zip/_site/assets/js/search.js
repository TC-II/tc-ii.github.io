// Placeholder para búsqueda futura (Lunr.js o similar)
