---
title: Playlist — Teoría Básica
playlist_url: "https://www.youtube.com/playlist?list=XXXX"
---

Videos recomendados para repaso de teoría.
