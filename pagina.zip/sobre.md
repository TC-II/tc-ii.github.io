---
layout: page
title: Sobre la cátedra
permalink: /sobre/
---

Este sitio centraliza el material de **Teoría de Circuitos II (ITBA)**: guías, exámenes, material de clases y recursos útiles.
