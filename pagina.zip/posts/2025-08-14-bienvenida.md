---
title: Bienvenidos al sitio de TC II
date: 2025-08-14
tags: [anuncios, sitio]
---

Publicamos el sitio de **Teoría de Circuitos II (ITBA)**.  
En las próximas semanas iremos agregando guías, clases y exámenes históricos.
