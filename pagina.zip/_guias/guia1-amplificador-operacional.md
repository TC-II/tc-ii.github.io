---
title: "Guía 1 - Amplificador operacional: circuitos elementales"
date: 2025-08-14
layout: item
tipo: "Guía"
archivo: /assets\Guias\25_14___TC2___Guía_1_2025.pdf
descripcion: "Introducción a los circuitos elementales con amplificadores operacionales"
preview: /assets/Guias/thumbs/Guia1.jpg
---
