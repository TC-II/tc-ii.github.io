---
title: Examen — 2023 (2° Turno)
anio: 2023
turno: "Julio"
archivo: /assets/examenes/2023-2.pdf
---

Temas: **frecuencia**, **filtros**, **estabilidad**.
